# بناء APK من الهاتف فقط — GroupFinance V2.1

هذا المشروع مجهز ليُبنى تلقائيًا بواسطة GitHub Actions، فلا تحتاج إلى كمبيوتر أو Android Studio.

## 1) إنشاء المستودع

افتح: https://github.com/new

- Owner: حسابك
- Repository name: `GroupFinanceAndroid`
- يفضل Public لتسهيل الوصول إلى Artifacts على حساب GitHub Free.
- اضغط Create repository.

## 2) رفع ملفات المشروع

فك ضغط ملف المشروع على الهاتف. من صفحة المستودع اختر **Add file → Upload files** وارفع ملفات المشروع ومجلداته مع الحفاظ على نفس البنية. يجب أن يكون `build.gradle` و`settings.gradle` داخل جذر المستودع، وأن يكون `.github/workflows/build-apk.yml` موجودًا في مكانه.

## 3) تشغيل البناء

افتح تبويب **Actions** ثم اختر **Build GroupFinance APK** ثم **Run workflow**. ويمكن للبناء أن يبدأ تلقائيًا أيضًا عند رفع/تعديل الملفات على فرع `main` أو `master`.

## 4) تنزيل APK

بعد نجاح العملية (علامة ✓): افتح تشغيل الـworkflow، ثم قسم **Artifacts**، ثم اضغط `GroupFinance-V2.1-debug-apk` لتنزيل ملف ZIP الذي يحتوي على `app-debug.apk`. GitHub يدعم حفظ ملفات البناء كـArtifacts وتنزيلها من صفحة تشغيل الـworkflow.

## ملاحظات

- هذه نسخة Debug للاختبار والتثبيت على هاتف Android.
- الإصدار: 2.1، versionCode: 3.
- لا توجد مفاتيح سرية أو كلمات مرور داخل المشروع.
- لا ترسل كلمة مرور GitHub أو رمز التحقق لأي شخص.
